﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Principal;
namespace Allocat.Web.Security
{
    public class CustomPrincipal : IPrincipal
    {
        public IIdentity Identity { get; private set; }

        public CustomPrincipal(string Username)
        {
            this.Identity = new GenericIdentity(Username);
        }
        public bool IsInRole(string role)
        {
            if (roles.Any(r => role.Contains(r)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int UserId { get; set; }
        public string FullName { get; set; }
        public string[] roles { get; set; }
        public string InfoType { get; set; }
        public string InfoName { get; set; }
        public int InfoId { get; set; }
    }

    public class CustomPrincipalSerializeModel
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string[] roles { get; set; }
        public string InfoType { get; set; }
        public string InfoName { get; set; }
        public int InfoId { get; set; }
    }
}