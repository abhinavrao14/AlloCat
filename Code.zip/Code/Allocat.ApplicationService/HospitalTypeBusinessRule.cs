﻿namespace Allocat.ApplicationService
{
    public class HospitalTypeBusinessRule : ValidationRules
    {
        public HospitalTypeBusinessRule()
        {
        }
    }
}