﻿namespace Allocat.ApplicationService
{
    public class StateBusinessRule : ValidationRules
    {
        public StateBusinessRule()
        {
        }
    }
}