﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allocat.DataModel
{
    public class TissueBankRoles_TissueBank
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
